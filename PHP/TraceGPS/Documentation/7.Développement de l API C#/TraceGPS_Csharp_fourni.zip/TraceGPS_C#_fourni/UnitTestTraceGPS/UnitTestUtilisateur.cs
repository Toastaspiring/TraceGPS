﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TraceGPS;

namespace UnitTestTraceGPS
{
    [TestClass]
    public class UnitTestUtilisateur
    {
        private Utilisateur utilisateur1;
        private Utilisateur utilisateur2;

        //Utilisez TestInitialize pour exécuter du code avant d'exécuter chaque test
        [TestInitialize()]
        public void MyTestInitialize()
        {
            utilisateur1 = new Utilisateur();

            int unId = 111;
            String unPseudo = "toto";
            String unMdpSha1 = "abcdef";
            String uneAdrMail = "toto@free.fr";
            String unNumTel = "1122334455";
            int unNiveau = 1;
            DateTime uneDateCreation = Convert.ToDateTime("21/06/2016 14:00:00");
            int unNbTraces = 3;
            DateTime uneDateDerniereTrace = Convert.ToDateTime("28/06/2016 14:00:00");
            utilisateur2 = new Utilisateur(unId, unPseudo, unMdpSha1, uneAdrMail, unNumTel, unNiveau, uneDateCreation, unNbTraces, uneDateDerniereTrace);
        }

        /// <summary>
        ///Test pour getId
        ///</summary>
        [TestMethod()]
        public void getIdTest()
        {
	
        }

        /// <summary>
        ///Test pour setId
        ///</summary>
        [TestMethod()]
        public void setIdTest()
        {

        }

        /// <summary>
        ///Test pour getPseudo
        ///</summary>
        [TestMethod()]
        public void getPseudoTest()
        {

        }

        /// <summary>
        ///Test pour setPseudo
        ///</summary>
        [TestMethod()]
        public void setPseudoTest()
        {

        }

        /// <summary>
        ///Test pour getMdpSha1
        ///</summary>
        [TestMethod()]
        public void getMdpSha1Test()
        {

        }

        /// <summary>
        ///Test pour setMdpSha1
        ///</summary>
        [TestMethod()]
        public void setMdpSha1Test()
        {

        }

        /// <summary>
        ///Test pour getAdrMail
        ///</summary>
        [TestMethod()]
        public void getAdrMailTest()
        {

        }

        /// <summary>
        ///Test pour setAdrMail
        ///</summary>
        [TestMethod()]
        public void setAdrMailTest()
        {

        }

        /// <summary>
        ///Test pour getNumTel
        ///</summary>
        [TestMethod()]
        public void getNumTelTest()
        {

        }

        /// <summary>
        ///Test pour setNumTel
        ///</summary>
        [TestMethod()]
        public void setNumTelTest()
        {

        }

        /// <summary>
        ///Test pour getNiveau
        ///</summary>
        [TestMethod()]
        public void getNiveauTest()
        {

        }

        /// <summary>
        ///Test pour setNiveau
        ///</summary>
        [TestMethod()]
        public void setNiveauTest()
        {

        }

        /// <summary>
        ///Test pour getDateCreation
        ///</summary>
        [TestMethod()]
        public void getDateCreationTest()
        {

        }

        /// <summary>
        ///Test pour setDateCreation
        ///</summary>
        [TestMethod()]
        public void setDateCreationTest()
        {

        }

        /// <summary>
        ///Test pour getNbTraces
        ///</summary>
        [TestMethod()]
        public void getNbTracesTest()
        {

        }

        /// <summary>
        ///Test pour setNbTraces
        ///</summary>
        [TestMethod()]
        public void setNbTracesTest()
        {

        }

        /// <summary>
        ///Test pour getDateDerniereTrace
        ///</summary>
        [TestMethod()]
        public void getDateDerniereTraceTest()
        {

        }

        /// <summary>
        ///Test pour setDateDerniereTrace
        ///</summary>
        [TestMethod()]
        public void setDateDerniereTraceTest()
        {

        }

        /// <summary>
        ///Test pour toString
        ///</summary>
        [TestMethod()]
        public void toStringTest()
        {
            String msg = "";
            msg += "id : " + "0" + "\n";
            msg += "pseudo : " + "" + "\n";
            msg += "mdpSha1 : " + "" + "\n";
            msg += "adrMail : " + "" + "\n";
            msg += "numTel : " + "" + "\n";
            msg += "niveau : " + "0" + "\n";
            msg += "dateCreation : " + "01/01/0001 00:00:00" + "\n";
            msg += "nbTraces : " + "0" + "\n";
            Assert.AreEqual(msg, utilisateur1.toString());

            msg = "";
            msg += "id : " + "111" + "\n";
            msg += "pseudo : " + "toto" + "\n";
            msg += "mdpSha1 : " + "abcdef" + "\n";
            msg += "adrMail : " + "toto@free.fr" + "\n";
            msg += "numTel : " + "11.22.33.44.55" + "\n";
            msg += "niveau : " + "1" + "\n";
            msg += "dateCreation : " + "21/06/2016 14:00:00" + "\n";
            msg += "nbTraces : " + "3" + "\n";
            msg += "dateDerniereTrace : " + "28/06/2016 14:00:00" + "\n";
            Assert.AreEqual(msg, utilisateur2.toString());
        }

    }
}
