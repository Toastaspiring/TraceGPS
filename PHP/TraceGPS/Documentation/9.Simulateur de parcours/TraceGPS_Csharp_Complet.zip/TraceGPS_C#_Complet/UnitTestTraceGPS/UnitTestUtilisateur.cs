﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TraceGPS;

namespace UnitTestTraceGPS
{
    [TestClass]
    public class UnitTestUtilisateur
    {
        private Utilisateur utilisateur1;
        private Utilisateur utilisateur2;

        //Utilisez TestInitialize pour exécuter du code avant d'exécuter chaque test
        [TestInitialize()]
        public void MyTestInitialize()
        {
            utilisateur1 = new Utilisateur();

            int unId = 111;
            String unPseudo = "toto";
            String unMdpSha1 = "abcdef";
            String uneAdrMail = "toto@free.fr";
            String unNumTel = "1122334455";
            int unNiveau = 1;
            DateTime uneDateCreation = Convert.ToDateTime("21/06/2016 14:00:00");
            int unNbTraces = 3;
            DateTime uneDateDerniereTrace = Convert.ToDateTime("28/06/2016 14:00:00");
            utilisateur2 = new Utilisateur(unId, unPseudo, unMdpSha1, uneAdrMail, unNumTel, unNiveau, uneDateCreation, unNbTraces, uneDateDerniereTrace);
        }

        /// <summary>
        ///Test pour getId
        ///</summary>
        [TestMethod()]
        public void getIdTest()
        {
            int id = utilisateur1.getId();
            Assert.AreEqual(0, id);

            id = utilisateur2.getId();
            Assert.AreEqual(111, id);	
        }

        /// <summary>
        ///Test pour setId
        ///</summary>
        [TestMethod()]
        public void setIdTest()
        {
            utilisateur1.setId(112);
            Assert.AreEqual(112, utilisateur1.getId());
        }

        /// <summary>
        ///Test pour getPseudo
        ///</summary>
        [TestMethod()]
        public void getPseudoTest()
        {
            String pseudo = utilisateur1.getPseudo();
            Assert.AreEqual("", pseudo);

            pseudo = utilisateur2.getPseudo();
            Assert.AreEqual("toto", pseudo);	
        }

        /// <summary>
        ///Test pour setPseudo
        ///</summary>
        [TestMethod()]
        public void setPseudoTest()
        {
            utilisateur1.setPseudo("titi");
            Assert.AreEqual("titi", utilisateur1.getPseudo());
        }

        /// <summary>
        ///Test pour getMdpSha1
        ///</summary>
        [TestMethod()]
        public void getMdpSha1Test()
        {
            String mdpSha1 = utilisateur1.getMdpSha1();
            Assert.AreEqual("", mdpSha1);

            mdpSha1 = utilisateur2.getMdpSha1();
            Assert.AreEqual("abcdef", mdpSha1);
        }

        /// <summary>
        ///Test pour setMdpSha1
        ///</summary>
        [TestMethod()]
        public void setMdpSha1Test()
        {
            utilisateur1.setMdpSha1("123456");
            Assert.AreEqual("123456", utilisateur1.getMdpSha1());
        }

        /// <summary>
        ///Test pour getAdrMail
        ///</summary>
        [TestMethod()]
        public void getAdrMailTest()
        {
            String adrMail = utilisateur1.getAdrMail();
            Assert.AreEqual("", adrMail);

            adrMail = utilisateur2.getAdrMail();
            Assert.AreEqual("toto@free.fr", adrMail);
        }

        /// <summary>
        ///Test pour setAdrMail
        ///</summary>
        [TestMethod()]
        public void setAdrMailTest()
        {
            utilisateur1.setAdrMail("titi@free.fr");
            Assert.AreEqual("titi@free.fr", utilisateur1.getAdrMail());
        }

        /// <summary>
        ///Test pour getNumTel
        ///</summary>
        [TestMethod()]
        public void getNumTelTest()
        {
            String numTel = utilisateur1.getNumTel();
            Assert.AreEqual("", numTel);

            numTel = utilisateur2.getNumTel();
            Assert.AreEqual("11.22.33.44.55", numTel);
        }

        /// <summary>
        ///Test pour setNumTel
        ///</summary>
        [TestMethod()]
        public void setNumTelTest()
        {
            utilisateur1.setNumTel("2233445566");
            Assert.AreEqual("22.33.44.55.66", utilisateur1.getNumTel());
        }

        /// <summary>
        ///Test pour getNiveau
        ///</summary>
        [TestMethod()]
        public void getNiveauTest()
        {
            int niveau = utilisateur1.getNiveau();
            Assert.AreEqual(0, niveau);

            niveau = utilisateur2.getNiveau();
            Assert.AreEqual(1, niveau);	
        }

        /// <summary>
        ///Test pour setNiveau
        ///</summary>
        [TestMethod()]
        public void setNiveauTest()
        {
            utilisateur1.setNiveau(2);
            Assert.AreEqual(2, utilisateur1.getNiveau());
        }

        /// <summary>
        ///Test pour getDateCreation
        ///</summary>
        [TestMethod()]
        public void getDateCreationTest()
        {
            DateTime dateCreation = utilisateur1.getDateCreation();
            Assert.AreEqual(dateCreation, DateTime.MinValue);

            String strDateCreation = utilisateur2.getDateCreation().ToString("dd/MM/yyyy HH:mm:ss");
            Assert.AreEqual("21/06/2016 14:00:00", strDateCreation);	
        }

        /// <summary>
        ///Test pour setDateCreation
        ///</summary>
        [TestMethod()]
        public void setDateCreationTest()
        {
            DateTime uneDateCreation = Convert.ToDateTime("21/06/2016 14:00:00");
            utilisateur1.setDateCreation(uneDateCreation);
            String strDateCreation = utilisateur1.getDateCreation().ToString("dd/MM/yyyy HH:mm:ss");
            Assert.AreEqual("21/06/2016 14:00:00", strDateCreation);
        }

        /// <summary>
        ///Test pour getNbTraces
        ///</summary>
        [TestMethod()]
        public void getNbTracesTest()
        {
            int nbTraces = utilisateur1.getNbTraces();
            Assert.AreEqual(0, nbTraces);

            nbTraces = utilisateur2.getNbTraces();
            Assert.AreEqual(3, nbTraces);	
        }

        /// <summary>
        ///Test pour setNbTraces
        ///</summary>
        [TestMethod()]
        public void setNbTracesTest()
        {
            utilisateur1.setNbTraces(4);
            Assert.AreEqual(4, utilisateur1.getNbTraces());
        }

        /// <summary>
        ///Test pour getDateDerniereTrace
        ///</summary>
        [TestMethod()]
        public void getDateDerniereTraceTest()
        {
            DateTime dateDerniereTrace = utilisateur1.getDateDerniereTrace();
            Assert.AreEqual(dateDerniereTrace, DateTime.MinValue);

            String strDateDerniereTrace = utilisateur2.getDateDerniereTrace().ToString("dd/MM/yyyy HH:mm:ss");
            Assert.AreEqual("28/06/2016 14:00:00", strDateDerniereTrace);	
        }

        /// <summary>
        ///Test pour setDateDerniereTrace
        ///</summary>
        [TestMethod()]
        public void setDateDerniereTraceTest()
        {
            DateTime dateDerniereTrace = Convert.ToDateTime("29/06/2016 14:00:00");
            utilisateur1.setDateDerniereTrace(dateDerniereTrace);
            String strDateDerniereTrace = utilisateur1.getDateDerniereTrace().ToString("dd/MM/yyyy HH:mm:ss");
            Assert.AreEqual("29/06/2016 14:00:00", strDateDerniereTrace);
        }

        /// <summary>
        ///Test pour toString
        ///</summary>
        [TestMethod()]
        public void toStringTest()
        {
            String msg = "";
            msg += "id : " + "0" + "\n";
            msg += "pseudo : " + "" + "\n";
            msg += "mdpSha1 : " + "" + "\n";
            msg += "adrMail : " + "" + "\n";
            msg += "numTel : " + "" + "\n";
            msg += "niveau : " + "0" + "\n";
            msg += "dateCreation : " + "01/01/0001 00:00:00" + "\n";
            msg += "nbTraces : " + "0" + "\n";
            Assert.AreEqual(msg, utilisateur1.toString());

            msg = "";
            msg += "id : " + "111" + "\n";
            msg += "pseudo : " + "toto" + "\n";
            msg += "mdpSha1 : " + "abcdef" + "\n";
            msg += "adrMail : " + "toto@free.fr" + "\n";
            msg += "numTel : " + "11.22.33.44.55" + "\n";
            msg += "niveau : " + "1" + "\n";
            msg += "dateCreation : " + "21/06/2016 14:00:00" + "\n";
            msg += "nbTraces : " + "3" + "\n";
            msg += "dateDerniereTrace : " + "28/06/2016 14:00:00" + "\n";
            Assert.AreEqual(msg, utilisateur2.toString());
        }

    }
}
